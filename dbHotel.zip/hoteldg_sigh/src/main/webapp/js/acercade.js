//window.addEventListener('resize', centerContent);
//
//function centerContent() {
//    const container = document.querySelector('.container');
//    const bodyHeight = window.innerHeight;
//    const containerHeight = container.offsetHeight;
//    
//    if (containerHeight < bodyHeight) {
//        const marginTop = (bodyHeight - containerHeight) / 2;
//        container.style.marginTop = `${marginTop}px`;
//    } else {
//        container.style.marginTop = '20px';
//    }
//}
//
//window.addEventListener('load', centerContent);
